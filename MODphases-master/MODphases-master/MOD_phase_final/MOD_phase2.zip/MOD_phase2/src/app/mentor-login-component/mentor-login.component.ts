import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
